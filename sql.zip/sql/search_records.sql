INSERT INTO `search_records`(`id`, `content`) VALUES ('b8ea06270de146be8d5ae58609113706', '一');
