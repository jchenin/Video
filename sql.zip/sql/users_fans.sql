INSERT INTO `users_fans`(`id`, `user_id`, `fans_id`) VALUES ('7d122b733d6e471ea4ff7b07795df933', '36008a3b8c1f4c4781a46242b234f663', '297d5c88c6d042a39e9faaf623213e1c');
INSERT INTO `users_fans`(`id`, `user_id`, `fans_id`) VALUES ('ab3f838a90c34d939690d74d9aff4513', '8d2b71b3f69c49fb92c12753d43a1929', '36008a3b8c1f4c4781a46242b234f663');
