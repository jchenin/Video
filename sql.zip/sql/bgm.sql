INSERT INTO `bgm`(`id`, `author`, `name`, `path`, `duration`, `isautoplay`) VALUES ('0a7a35e0686d4a5785009544253b4232', '任然', '走不出的回忆', '/bgms/任然 - 走不出的回忆.mp3', '00:00', 'false');
INSERT INTO `bgm`(`id`, `author`, `name`, `path`, `duration`, `isautoplay`) VALUES ('766374de9c5344ccace8fa58ad3550e5', '金玟岐', '岁月神偷', '/bgms/金玟岐-岁月神偷.mp3', '00:00', 'false');
INSERT INTO `bgm`(`id`, `author`, `name`, `path`, `duration`, `isautoplay`) VALUES ('c4eeed47ae1743fd9c6663772759125b', '房东的猫', '美好事物', '/bgms/房东的猫 - 美好事物.mp3', '00:00', 'false');
