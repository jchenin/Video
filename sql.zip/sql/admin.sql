INSERT INTO `admin`(`username`, `password`) VALUES ('0', '0');
INSERT INTO `admin`(`username`, `password`) VALUES ('aa', 'aa');
INSERT INTO `admin`(`username`, `password`) VALUES ('ceshi', '123');
INSERT INTO `admin`(`username`, `password`) VALUES ('cj', '1');
INSERT INTO `admin`(`username`, `password`) VALUES ('cj9', '1');
INSERT INTO `admin`(`username`, `password`) VALUES ('linux', 'linux');
INSERT INTO `admin`(`username`, `password`) VALUES ('qq', 'qq');
